Documentation for CDAS file package

Description: This file describes the components of this CDAS data delivery package.


Main Directory
File List:
1. Delivery File Readme: README.txt


Directory: nlst_780
Description: Participant and image data for IDC
File List:
1. CSV Dataset: nlst780.idc.delivery.052821.zip


